import numpy as np
import sys
import pickle
from tqdm import tqdm

if len(sys.argv) < 4:
    print ("Command must be in the format: python CreateSplits.py <Dataset Size> <Ensemble Size> <Name>")
    sys.exit()
    
datasetSize = int(sys.argv[1])
ensembleSize = int(sys.argv[2])
name = sys.argv[3]

if ensembleSize % 2 != 0:
    print ("Size of the ensemble must be an even number")
    sys.exit()

if ensembleSize <= 0 or datasetSize <= 0:
    print ("<Dataset Size> and <Ensemble Size> must be larger than 0")
    sys.exit()
    
halfEnsembleSize = ensembleSize // 2

codes = set()
for i in tqdm(range(datasetSize), position = 0, leave = True):
    failures = 0
    while True:
        code = tuple( np.random.permutation(([0] * halfEnsembleSize) + ([1] * halfEnsembleSize)) )
        codes.add(code)
        if len(codes) > i:
            break
        else:
            failures += 1
            if failures > 256:
                print ("Assignment failed. Consider making the ensemble size larger")
                sys.exit()

codes = np.array(list(codes)).T
with open("./data/{}.pkl".format(name), 'wb') as fout:
    pickle.dump(codes, fout)

print ("Created {} splits from dataset of size {} at ./data/{}.pkl".format(*codes.shape, name))