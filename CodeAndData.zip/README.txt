This directory contains info for how to replicate our results for MNIST and CIFAR-10. Code for replicating our results on CelebA are forthcoming.

How to run:

First make sure the subdirectories "./data" and "./out" are present. Data splits and training data will be stored in the former, while trained models, samples, and noise will be stored in the latter.

Then use the provided .yml to set up the required environment:

conda env create -f env.yml
conda activate trainingattribution

To begin, run CreateSplits.py to generate the splits.

(for MNIST) python CreateSplits.py 10000 16 mnist
(for CIFAR-10) python CreateSplits.py 60000 20 cifar

This will generate ./data/mnist.pkl and ./data/cifar.pkl. We can then train the models:

(for MNIST) python TrainModel.py ./data/mnist.pkl <Split> 501 <Device> -m
(for CIFAR-10) python TrainModel.py ./data/cifar.pkl <Split> 25 <Device> -c

<Device> is the cuda device you want to run the training on, and <Split> will need to be run for values from 0 to 15 for MNIST and from 0 to 19 for CIFAR-10. This will generate the trained output models as ./out/MNIST_split<split>_ckpt.pt and ./out/CIFAR_split<split>_ckpt.pt

Once the models are trained, we can start generating samples. First, generate the exogenous noise with

(for MNIST) python GenerateNoise.py <NoiseName> 1 -m
(for CIFAR-10) python GenerateNoise.py <NoiseName> 1 -c

The 1 is the batch size. This can be increased to generate more samples at one time. <NoiseName> can be arbitrarily chosen. This will output a file at ./out/<NoiseName>.pkl

We then generate a sample using an ensemble of models with Sample.py:

CUBLAS_WORKSPACE_CONFIG=:4096:8 python Sample.py <SampleName> ./out/MNIST_split0_ckpt.pt,./out/MNIST_split1_ckpt.pt ./out/<NoiseName>.pkl <Device>

The output will be placed at ./out/<SampleName>.pkl. The file is a pickle file, and the content is a tensor of shape (<batchshape>, 1, 28, 28) for MNIST and (<batchshape>, 3, 32, 32) for CIFAR-10. The first dimension indexes the batch, the second indexes the channel, and the rest index the pixel coordinate.

"CUBLAS_WORKSPACE_CONFIG=:4096:8" is required since the sampling uses deterministic algorithms. This will generate a sample using the models stored in ./out/MNIST_split0_ckpt.pt and ./out/MNIST_split1_ckpt.pt. The comma separated list can be added to to include more models. This can be used to perform ablation experiments when the same model is used as input.

To compute the Jacobian, you sample instead with Jacobian.py:

CUBLAS_WORKSPACE_CONFIG=:4096:8 python Jacobian.py <SampleName> ./out/MNIST_split0_ckpt.pt,./out/MNIST_split1_ckpt.pt ./out/<NoiseName>.pkl <Device>

The semantics are identical to Sample.py. The output will be a pair of tensors, the first of which should be identical to the output of Sample.py. The second one has an additional index at the front (i.e. it is 5 dimensional). The first index indexes the model whose influence is infinitesimally increased. In other words, entry 0 of the second tensor contains a tensor of identical shape to the first tensor, where the entries approximate how the values of the first tensor would change if the influence of the first model (in this case the model stored in ./out/MNIST_split0_ckpt.pt) is increased.



model.py contains the model definition and does not need to be viewed.