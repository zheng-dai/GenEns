./data is used to store splits and data
