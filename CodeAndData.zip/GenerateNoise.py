import torch
import pickle
import sys

if len(sys.argv) < 4:
    print ("Command must be in the format: python GenerateNoise.py <Output file> <Batch Size> <MNIST/CIFAR>")
    sys.exit()

filename = sys.argv[1]
batchsize = int(sys.argv[2])

if sys.argv[3].lower() == "-c":
    noise = torch.normal(0,1,(1001,batchsize,3,32,32))
elif sys.argv[3].lower() == "-m":
    noise = torch.normal(0,1,(1001,batchsize,1,28,28))
else:
    print ("MNIST/CIFAR flag must be either -c for CIFAR-10 or -m for MNIST")
    sys.exit()
    
with open("./out/{}.pkl".format(filename), 'wb') as fout:
    pickle.dump(noise, fout)