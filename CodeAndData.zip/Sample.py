import numpy as np
import sys
import pickle
from tqdm import tqdm

import model
import torch

if len(sys.argv) < 5:
    print ("Command must be in the format: python Sample.py <Output> "
           +"<Checkpoint files (comma separated, no space)> <Noise file> <Device>")
    sys.exit()
    
torch.use_deterministic_algorithms(True)
device = int(sys.argv[4])
torch.cuda.set_device(device)

with open(sys.argv[3], 'rb') as fin:
    noise = pickle.load(fin)
cifar = noise.size(2) == 3

def getModel(fname, cifar):
    print ("Loading model from {}".format(fname))
    checkpoint = torch.load(fname, map_location = "cpu")
    if cifar:
        diff = model.UNet(3, 1000, 128, [1, 2, 2, 2], [1], 2, 0.1)
    else:
        diff = model.UNet(1, 1000, 128, [1, 2, 2], [1], 2, 0.1)
    diff.load_state_dict(checkpoint["model_state_dict"])
    diff.eval()
    return diff

outputfilename = sys.argv[1]
modelfiles = sys.argv[2].split(',')
ensemble = [getModel(filename, cifar) for filename in modelfiles]

def denoiseInner(models, vrs, noisemult, expand, noise):
    iteration = 0
    with torch.no_grad():
        sample = noise[iteration].cuda()
        iteration += 1
        
        for i,vr,no,ex in tqdm( list(zip(range(1000), vrs, noisemult, expand))[::-1], position = 0, leave = True):
            predNoise = torch.stack([
                                model(
                                sample,
                                torch.tensor([i for _ in range(sample.size(0))], device = "cuda")
                                ) for model in models])
            
            predNoise = torch.mean(predNoise, dim = 0)
            
            eps = noise[iteration].cuda()
            iteration += 1
            
            sample = ex*(sample - (no * predNoise)) + (vr * eps)
        sample = torch.clip(sample, min=-1, max=1)
        sample = (sample+1)/2
        return sample
    
def denoise(models, noise):
    betas = np.linspace(1e-4, 0.02, 1000)
    alphas = 1 - betas
    atilde = np.exp(np.cumsum(np.log(alphas)))
    
    vrs = (atilde[1:]/atilde[:-1]) * (betas[1:])
    vrs = np.concatenate(([0], vrs))**0.5
    noisemult = (1-alphas)/((1-atilde)**0.5)
    expand = (1/alphas) ** 0.5
    
    models = [model.cuda() for model in models]
    results = denoiseInner(models, vrs, noisemult, expand, noise).cpu()
    models = [model.cpu() for model in models]
    return results

pictures = denoise(ensemble, noise)
with open("./out/{}.pkl".format(outputfilename), 'wb') as fout:
    pickle.dump(pictures, fout)