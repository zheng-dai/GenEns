import numpy as np
import sys
import pickle
from tqdm import tqdm

import model

import torch
import torchvision
from torchvision import transforms
import torch.optim as optim

if len(sys.argv) < 6:
    print ("Command must be in the format: python TrainModel.py <File with splits> <Split> <Training epochs> <Device> <Dataset>")
    sys.exit()
    
filename = sys.argv[1]
split = int(sys.argv[2])
epochs = int(sys.argv[3])

device = int(sys.argv[4])
torch.cuda.set_device(device)

def generateSplit(dataset):
    with open(filename, 'rb') as fin:
        splitIndices = pickle.load(fin)[split]

    if len(splitIndices) != len(dataset):
        print ("Mismatch between split file and dataset detected. "
               +"Dataset contains {} elements, split is for a dataset of {} elemets".format(len(dataset),len(splitIndices)))
        sys.exit()
        
    return torch.utils.data.Subset(dataset, torch.tensor(np.argwhere(splitIndices).reshape(-1)))

if sys.argv[5].lower() == "-c":
    # Load CIFAR-10
    trainset = torchvision.datasets.CIFAR10(
            root='./data', train=True, download=True,
            transform=transforms.Compose([
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)),
                transforms.RandomHorizontalFlip()
            ]))
    testset = torchvision.datasets.CIFAR10(
            root='./data', train=False, download=True,
            transform=transforms.Compose([
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)),
                transforms.RandomHorizontalFlip()
            ]))
    dataset = torch.utils.data.ConcatDataset((trainset, testset))
    dataset = generateSplit(dataset)
    
    sampler = torch.utils.data.RandomSampler(dataset, replacement=True, num_samples=128*10000)
    loader = torch.utils.data.DataLoader(dataset, sampler=sampler, batch_size=128)
    diff = model.UNet(3, 1000, 128, [1, 2, 2, 2], [1], 2, 0.1).train()
    name = "CIFAR10_split{}".format(split)
elif sys.argv[5].lower() == "-m":
    # Load MNIST
    dataset = torchvision.datasets.MNIST(
            root='./data', train=False, download=True,
            transform=transforms.Compose([
                transforms.ToTensor(),
                transforms.Normalize((0.5), (0.5)),
            ]))
    dataset = generateSplit(dataset)
    
    loader = torch.utils.data.DataLoader(dataset, batch_size=128, shuffle=True, drop_last=True)
    diff = model.UNet(1, 1000, 128, [1, 2, 2], [1], 2, 0.1).train()
    name = "MNIST_split{}".format(split)
else:
    print ("Dataset flag must be either -c for CIFAR-10 or -m for MNIST")
    sys.exit()

def train(loader, model, epochs, name):
    betas = np.linspace(1e-4, 0.02, 1000)
    alphas = 1 - betas
    atilde = np.exp(np.cumsum(np.log(alphas)))
    
    w_org = torch.tensor( atilde**0.5, device = "cuda" ).float()
    w_noise = torch.tensor( (1-atilde)**0.5, device = "cuda" ).float()
    
    optimizer = optim.Adam(model.parameters(), lr=2e-4)
    
    losstrace = []
    for epoch in range(epochs):
        with tqdm(loader, position=0, leave=True) as pbar:
            for databatch, _ in pbar:
                optimizer.zero_grad()
                batchsize = databatch.size(0)
                databatch = databatch.cuda()

                t = torch.randint(0, 1000, (batchsize,), device = "cuda")
                noise = torch.normal(0, 1, databatch.shape, device = "cuda")
                noisedImage = (w_org[t].view(-1,1,1,1) * databatch) + (w_noise[t].view(-1,1,1,1) * noise)

                output = torch.sum( ((model(noisedImage, t) - noise)**2).view(batchsize, -1), dim = 1)
                output = torch.mean(output)

                output.backward()
                optimizer.step()

                result = output.item()
                losstrace.append(result)
                pbar.set_description("Epoch{}: loss={:.5f}".format(epoch, result))

        torch.save({
            'epoch': epoch,
            'model_state_dict': model.state_dict(),
            'optimizer_state_dict': optimizer.state_dict(),
            'loss': losstrace
            }, "./out/{}_ckpt.pt".format(name))
        print ("Model saved in ./out/{}_ckpt.pt".format(name))
        torch.cuda.empty_cache()
        
train(loader, diff.cuda(), epochs, name)